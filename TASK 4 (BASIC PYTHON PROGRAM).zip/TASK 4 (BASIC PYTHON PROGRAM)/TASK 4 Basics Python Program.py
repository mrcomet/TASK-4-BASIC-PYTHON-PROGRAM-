#!/usr/bin/env python
# coding: utf-8

# # Q1. Swap Case
# 

# In[ ]:


def swap_case(s):
    x = ""
    for let in s:
        if let.isupper() == True:
            x+=(let.lower())
        else:
            x+=(let.upper())
    return x
    

if __name__ == '__main__':
    s = input()
    result = swap_case(s)
    print(result)


# # Q.2 Split String and Join

# In[ ]:


def split_and_join(line):
    line=line.split()
    line='-'.join(line)
    return line
if __name__ == '__main__':
    line = input()
    result = split_and_join(line)
    print(result)


# #  Q3. Whats Your Name

# In[5]:


def print_full_name(first, last):
    last=last + '!'
    print('Hello',first,last, 'You just delved into python.')


# # Q4. Mutation

# In[ ]:


def mutate_string(string, position, character):
    l = list(string)
    l[position] = character;
    string = ''.join(l);
    return string

if __name__ == '__main__':
    s = input()
    i, c = input().split()
    s_new = mutate_string(s, int(i), c)
    print(s_new)


# # Q5. Find A String

# In[ ]:


def count_substring(string, sub_string):
    count=0
    for i in range(len(string)):
        if string[i:i+len(sub_string)]==sub_string:
            count+=1
    return count

if __name__ == '__main__':
    string = input().strip()
    sub_string = input().strip()
    
    count = count_substring(string, sub_string)
    print(count)


# # Q6. String Validator

# In[ ]:


s = input()
print(any(a.isalnum() for a in s) )
print(any(a.isalpha() for a in s) )
print(any(a.isdigit() for a in s) )
print(any(a.islower() for a in s) )
print(any(a.isupper() for a in s) )


# # Q7. Text Alignment
# 
# 

# In[ ]:


#Replace all ______ with rjust, ljust or center. 

thickness = int(input()) #This must be an odd number
c = 'H'

#Top Cone
for i in range(thickness):
    print((c*i).rjust(thickness-1)+c+(c*i).ljust(thickness-1))

# Top Pillars
for i in range(thickness+1):
    print((c*thickness).center(thickness*2)+(c*thickness).center(thickness*6))

# Middle Belt
for i in range((thickness+1)//2):
    print((c*thickness*5).center(thickness*6))

# Bottom Pillars
for i in range(thickness+1):
    print((c*thickness).center(thickness*2)+(c*thickness).center(thickness*6))

# Bottom Cone
for i in range(thickness):
    print(((c*(thickness-i-1)).rjust(thickness)+c+(c*(thickness-i-1)).ljust(thickness)).rjust(thickness*6))


# # Q8. Text Wrap

# In[ ]:


import textwrap

def wrap(string, max_width):
    for i in range(0,len(string)+1,max_width):
        result=string[i:i+max_width]
        if len(result)==max_width:
            print(result)
        else:
            return(result)

if __name__ == '__main__':


# # Q9. Designer Door Mat

# In[ ]:


N, M = map(int,input().split())
for i in range(1,N,2): 
    print((i * ".|.").center(M, "-"))
print("WELCOME".center(M,"-"))
for i in range(N-2,-1,-2): 
    print((i * ".|.").center(M, "-"))


# # Q10. String Formatting

# In[ ]:


def print_formatted(number):
    width = len(bin(number)[2:])
    for i in range(1, number+1):
        deci = str(i)
        octa = oct(i)[2:]
        hexa = hex(i)[2:].upper()
        bina = bin(i)[2:]

if __name__ == '__main__':
    n = int(input())
    print_formatted(n)

